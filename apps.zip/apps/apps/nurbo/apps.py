from django.apps import AppConfig


class NurboConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.nurbo'
